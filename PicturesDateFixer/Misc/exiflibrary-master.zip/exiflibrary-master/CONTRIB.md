# Contributors to ExifLibrary

* [oozcitak](https://github.com/oozcitak)
* [Devedse](https://github.com/devedse)
  - Conversion to .Net Standard
  - Automatic builds
