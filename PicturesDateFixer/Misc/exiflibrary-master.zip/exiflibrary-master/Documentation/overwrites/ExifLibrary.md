---
uid: ExifLibrary
summary: *content
---
The ExifLibrary namespace contains components for extracting image metadata.