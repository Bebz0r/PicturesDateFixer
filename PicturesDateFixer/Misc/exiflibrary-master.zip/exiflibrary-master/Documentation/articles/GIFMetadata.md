---
uid: Articles.GIFMetadata
title: GIF Metadata
---

# GIF Metadata #

Tag Name | Tag ID | Tag ID (Hex) | Property Type | Value Type
---------|--------|--------------|---------------|-----------
[GIFComment](xref:ExifLibrary.ExifTag.GIFComment) | 0 | 0x0000 | [GIFComment](xref:ExifLibrary.GIFComment) | string

