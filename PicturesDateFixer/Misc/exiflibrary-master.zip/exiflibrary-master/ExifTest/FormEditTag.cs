﻿using System.Windows.Forms;

namespace ExifTest
{
    public partial class FormEditTag : Form
    {
        public FormEditTag()
        {
            InitializeComponent();
        }
    }
}
